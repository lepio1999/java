package java_day9_실습;

import java.util.Scanner;

public class java_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[][] sch = new String[2][5];
		Scanner sc = new Scanner(System.in);
		
		System.out.println("일 입력하세요");
		String day_ = sc.nextLine();
		
		
			
			
		}
		
		
		
		
	}


