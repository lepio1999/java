package java_day9_실습;

public class James {
	
	int age;
	String name;
	boolean isMarried;
	int child;

}
