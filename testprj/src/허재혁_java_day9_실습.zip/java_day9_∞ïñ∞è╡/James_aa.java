package java_day9_실습;

public class James_aa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		James a = new James();
		a.age =  40;
		a.child = 3;
		a.isMarried = true;
		a.name = "james";
		
		System.out.println("이름: "+a.name);
		System.out.println("나이: "+a.age+"살");
		System.out.println("결혼 여부: "+a.isMarried);
		System.out.println("자녀 수"+a.child+"명");
		
		

	}

}
