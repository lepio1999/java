package java_day9_실습;

public class Shopping {

	String number;
	String id;
	String day;
	String name;
	String number2;
	String add;

	

}
