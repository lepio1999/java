package java_day9_실습;

public class Score {
	
	String name;
	int kor;
	int eng;
	int avg;
	

}
